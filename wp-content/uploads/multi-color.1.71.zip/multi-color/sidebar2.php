<div class="sidebar" id="sidebar2">
    <ul>
        <?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(2) ) : else : ?>
	<li>
	    <h2><?php _e('Archives','multi-color'); ?></h2>
	    <ul>
		<?php wp_get_archives('type=monthly'); ?>
	    </ul>
	</li>
	<li>
	    <h2><?php _e('Tags','multi-color'); ?></h2>
	    <div>
                <?php wp_tag_cloud(); ?>
	    </div>
	</li>
	<?php endif; ?>
    </ul>
</div>