/* Multi-Color JS */

function smoothscroll(id){
    var $j = jQuery.noConflict();
    if($j.browser.opera){
        $j('html').animate({ scrollTop: $j('#'+id).offset().top }, 500);
    } else {
        $j('html, body').animate({ scrollTop: $j('#'+id).offset().top }, 500);
    }
}

function show_sharepanel() {
    var $j = jQuery.noConflict();
    $j('#sharepanel').fadeIn(1000);
}

function hide_sharepanel() {
    var $j = jQuery.noConflict();
    $j('#sharepanel').fadeOut(500);
}

function show_comments() {
    var $j = jQuery.noConflict();
    document.getElementById('trackbacktab').style.borderBottomColor = "#666";
    document.getElementById('trackbacktab').style.backgroundColor = "#ddd";
    document.getElementById('commenttab').style.borderBottomColor = "#fff";
    document.getElementById('commenttab').style.backgroundColor = "#fff";
    $j('#trackbacklist').hide('fast');
    $j('#commentlist').show('fast');
}

function show_trackbacks() {
    var $j = jQuery.noConflict();
    document.getElementById('commenttab').style.borderBottomColor = "#666";
    document.getElementById('commenttab').style.backgroundColor = "#ddd";
    document.getElementById('trackbacktab').style.borderBottomColor = "#fff";
    document.getElementById('trackbacktab').style.backgroundColor = "#fff";
    $j('#commentlist').hide('fast');
    $j('#trackbacklist').show('fast');
}