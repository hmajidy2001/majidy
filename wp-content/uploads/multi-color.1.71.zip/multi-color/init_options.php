<?php
    $options = get_option('mc_options');
    if(trim($options['mc_postmeta']) == '') { $options['mc_postmeta'] = 'categories'; }
?>