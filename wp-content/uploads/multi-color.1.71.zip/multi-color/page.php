<?php get_header(); ?>
<?php include(TEMPLATEPATH . '/init_options.php'); ?>
<?php if($options['mc_sidebar_layout'] == 'l') {
    include(TEMPLATEPATH . '/sidebar1.php');
} else if($options['mc_sidebar_layout'] == 'll') {
    include(TEMPLATEPATH . '/sidebar1.php');
    include(TEMPLATEPATH . '/sidebar2.php');
} else if($options['mc_sidebar_layout'] == 'lr') {
    include(TEMPLATEPATH . '/sidebar2.php');
}
?>
<div id="content">
    <?php $count = 0; ?>
    <?php if (have_posts()) : ?>
        <?php while (have_posts()) : the_post(); $count ++; ?>
            <div <?php post_class('box-'.$count) ?> id="post-<?php the_ID(); ?>">
                <h2 class="posttitle"><?php the_title(); ?></h2>
                <div class="entry">
                    <?php the_content('Read More'); ?>
                    <div class="clear"></div>
                    <?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
                </div>
                <?php edit_post_link('Edit this entry.', '<p>', '</p>'); ?>
            </div>
            <?php comments_template('', true); ?>
        <?php endwhile; ?>
    <?php else : ?>
        <div class="post box-1">
            <h2><?php _e('No Results','multi-color'); ?></h2>
            <div class="entry">
                <p><?php _e('Sorry, but you are looking for something that is not here.','multi-color'); ?></p>
                <p><?php _e('Try using the Search.','multi-color'); ?></p>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php if($options['mc_sidebar_layout'] == 'r') {
    include(TEMPLATEPATH . '/sidebar1.php');
} else if($options['mc_sidebar_layout'] == 'rr') {
    include(TEMPLATEPATH . '/sidebar1.php');
    include(TEMPLATEPATH . '/sidebar2.php');
} else if($options['mc_sidebar_layout'] == 'lr') {
    include(TEMPLATEPATH . '/sidebar1.php');
}
?>
<div class="clear"></div>
<?php get_footer(); ?>