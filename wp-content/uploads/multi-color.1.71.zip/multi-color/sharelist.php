<?php
    define("SHARETITLE",get_the_title());
    define("SHAREPERMALINK",get_permalink());
    define("SHAREEXCERPT",htmlspecialchars(get_the_excerpt()));
    define("SHAREBLOGNAME",get_bloginfo('name'));
    $sharelist = array();
    $shareurls = array();
    array_push($sharelist,"delicious","designfloat","digg","email","facebook","friendfeed","google","linkedin","live","mixx","myspace","netvibes","newsvine","reddit","rss","stumbleupon","technorati","twitter","yahoobuzz","yahoo");
    array_push($shareurls,
        'http://delicious.com/post?url='.SHAREPERMALINK.'&title='.SHARETITLE.'&notes='.SHAREEXCERPT,
        'http://www.designfloat.com/submit.php?url='.SHAREPERMALINK.'&title='.SHARETITLE,
        'http://digg.com/submit?phase=2&url='.SHAREPERMALINK.'&title='.SHARETITLE.'&bodytext='.SHAREEXCERPT,
        'mailto:?subject='.SHARETITLE.'&body='.SHAREPERMALINK,
        'http://www.facebook.com/share.php?u='.SHAREPERMALINK.'&t='.SHARETITLE,
        'http://www.friendfeed.com/share?title='.SHARETITLE.'&link='.SHAREPERMALINK,
        'http://www.google.com/bookmarks/mark?op=edit&bkmk='.SHAREPERMALINK.'&title='.SHARETITLE.'&annotation='.SHAREEXCERPT,
        'http://www.linkedin.com/shareArticle?mini=true&url='.SHAREPERMALINK.'&title='.SHARETITLE.'&source='.SHAREBLOGNAME.'&summary='.SHAREEXCERPT,
        'https://favorites.live.com/quickadd.aspx?marklet=1&url='.SHAREPERMALINK.'&title='.SHARETITLE,
        'http://www.mixx.com/submit?page_url='.SHAREPERMALINK.'&title='.SHARETITLE,
        'http://www.myspace.com/Modules/PostTo/Pages/?u='.SHAREPERMALINK.'&t='.SHARETITLE,
        'http://www.netvibes.com/share?title='.SHARETITLE.'&url='.SHAREPERMALINK,
        'http://www.newsvine.com/_tools/seed&save?u='.SHAREPERMALINK.'&h='.SHARETITLE,
        'http://reddit.com/submit?url='.SHAREPERMALINK.'&title='.SHARETITLE,
        get_bloginfo('rss2_url'),
        'http://www.stumbleupon.com/submit?url='.SHAREPERMALINK.'&title='.SHARETITLE,
        'http://technorati.com/faves?add='.SHAREPERMALINK,
        'http://twitter.com/home?status='.SHARETITLE.'%20-%20'.SHAREPERMALINK,
        'http://buzz.yahoo.com/submit/?submitUrl='.SHAREPERMALINK.'&submitHeadline='.SHARETITLE.'&submitSummary='.SHAREEXCERPT.'&submitCategory=science&submitAssetType=text',
        'http://bookmarks.yahoo.com/toolbar/savebm?u='.SHAREPERMALINK.'&t='.SHARETITLE.'&opener=bm&ei=UTF-8&d='.SHAREEXCERPT
    );
    
    $scount = 0;
    foreach($sharelist as $shareentry) {
        echo '<a href="'.$shareurls[$scount].'" title="Share this on '.ucwords($shareentry).'"><img src="'.get_bloginfo('template_url').'/images/bookmark_icons/'.$shareentry.'.png" /></a>'."\n";
        $scount++;
    }
    
    echo '<img class="hidebtn" onclick="hide_sharepanel()" src="'.get_bloginfo('template_url').'/images/hide_share.png" />';
?>