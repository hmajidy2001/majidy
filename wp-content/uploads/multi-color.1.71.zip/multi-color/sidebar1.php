<div class="sidebar" id="sidebar1">
    <ul>
        <div class="searchdivleft">
            <div class="searchdivright">
                <form id="searchform" method="get" action="">
                    <input type="text" name="s" id="s" value="<?php _e('Search','multi-color'); ?>..." onfocus="if (this.value == '<?php _e('Search','multi-color'); ?>...') {this.value = '';}" onblur="if (this.value == '') {this.value = '<?php _e('Search','multi-color'); ?>...';}" />
                    <input type="submit" name="searchbtn" id="searchbtn" value="<?php _e('Go','multi-color'); ?>" />
                </form>
            </div>
        </div>
        <?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(1) ) : else : ?>
	<li>
	    <h2><?php _e('Archives','multi-color'); ?></h2>
	    <ul>
		<?php wp_get_archives('type=monthly'); ?>
	    </ul>
	</li>
	<li>
	    <h2><?php _e('Tags','multi-color'); ?></h2>
	    <div>
                <?php wp_tag_cloud(); ?>
	    </div>
	</li>
	<?php endif; ?>
    </ul>
</div>