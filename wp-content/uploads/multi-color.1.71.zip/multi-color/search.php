<?php get_header(); ?>
<?php include(TEMPLATEPATH . '/init_options.php'); ?>
<?php if($options['mc_sidebar_layout'] == 'l') {
    include(TEMPLATEPATH . '/sidebar1.php');
} else if($options['mc_sidebar_layout'] == 'll') {
    include(TEMPLATEPATH . '/sidebar1.php');
    include(TEMPLATEPATH . '/sidebar2.php');
} else if($options['mc_sidebar_layout'] == 'lr') {
    include(TEMPLATEPATH . '/sidebar2.php');
}
?>
<div id="content">
    <?php $count = 0; ?>
    <?php if (have_posts()) : ?>
        <h2 class="pagetitle"><?php _e('Search Results','multi-color'); ?></h2>
        <?php while (have_posts()) : the_post(); $count ++; ?>
            <div <?php post_class('box-'.$count) ?> id="post-<?php the_ID(); ?>">
                <h2 class="posttitle"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php _e('Permanent Link to','multi-color'); ?> <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
                <div class="postinfo">
                    <span class="date"><?php the_time('M jS, y') ?></span>
                    / <span class="comments"><?php comments_popup_link('0 Comments', '1 Comment', '% Comments','','Comments Off'); ?></span>
                    <?php edit_post_link('Edit this Entry', '/<span class="edit-link">', '</span>'); ?>
                </div>
                <div class="entry">
                    <?php the_content('Read More'); ?>
                    <div class="clear"></div>
                    <?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
                </div>
                <?php if($options['mc_postmeta'] != 'none') { ?>
                    <?php if($options['mc_postmeta'] == 'categories') { ?>
                        <div class="postmeta"><span class="postcategory"><?php the_category(', ') ?></span></div>
                    <?php } else if($options['mc_postmeta'] == 'tags') { ?>
                        <div class="postmeta"><span class="posttags"><?php the_tags('<img src="'.get_bloginfo('template_url').'/images/tag_icon.png" />', ', ', ''); ?></span></div>
                    <?php } ?>
                <?php } ?>
            </div>
        <?php endwhile; ?>
        <?php include(TEMPLATEPATH . '/navigation.php'); ?>
    <?php else : ?>
        <div class="post box-1">
            <h2><?php _e('No Results','multi-color'); ?></h2>
            <div class="entry">
                <p><?php _e('Sorry, but you are looking for something that is not here.','multi-color'); ?></p>
                <p><?php _e('Try using the Search.','multi-color'); ?></p>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php if($options['mc_sidebar_layout'] == 'r') {
    include(TEMPLATEPATH . '/sidebar1.php');
} else if($options['mc_sidebar_layout'] == 'rr') {
    include(TEMPLATEPATH . '/sidebar1.php');
    include(TEMPLATEPATH . '/sidebar2.php');
} else if($options['mc_sidebar_layout'] == 'lr') {
    include(TEMPLATEPATH . '/sidebar1.php');
}
?>
<div class="clear"></div>
<?php get_footer(); ?>