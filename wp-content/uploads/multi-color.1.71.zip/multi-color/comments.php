<?php
// Do not delete these lines
if (!empty($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
    die ('Please do not load this page directly. Thanks!');
if ( post_password_required() ) { ?>
    <p class="nocomments"><?php _e('This post is password protected. Enter the password to view comments.','multi-color'); ?></p>
<?php
    return;
}
?>
<!-- You can start editing here. -->
<?php if ( have_comments() ) : ?>
<?php $commentscount = 0; if ( ! empty($comments_by_type['comment']) ) { $commentscount = count($comments_by_type['comment']); } ?>
<?php $pingscount = 0; if ( ! empty($comments_by_type['pings']) ) { $pingscount = count($comments_by_type['pings']); } ?>
    <!--div class="navigation">
        <div class="alignleft"><?php previous_comments_link() ?></div>
        <div class="alignright"><?php next_comments_link() ?></div>
        <div class="clear"></div>
    </div-->
    <ul id="comments">
        <li id="commenttab"class="default" onclick="show_comments()"><?php _e('Comments','multi-color'); ?></li>
        <li id="trackbacktab" onclick="show_trackbacks()"><?php _e('Trackbacks','multi-color'); ?></li>
        <li id="writetab" onclick="smoothscroll('respond')"><?php _e('Leave a Comment','multi-color'); ?></li>
    </ul>
    <div class="content">
        <ul id="commentlist" class="commentlist">
            <?php if($commentscount > 0) { wp_list_comments('type=comment&callback=comments_callback'); } else { _e('<li>No comments yet</li>','multi-color'); } ?>
        </ul>
        <ul id="trackbacklist" class="commentlist">
            <?php if($pingscount > 0) { wp_list_comments('type=pings&callback=trackbacks_callback'); } else { _e('<li>No trackbacks yet</li>','multi-color'); } ?>
        </ul>
    </div>
<?php else : // this is displayed if there are no comments so far ?>
    <?php if ( comments_open() ) : ?>
            <!-- If comments are open, but there are no comments. -->
     <?php else : // comments are closed ?>
            <!-- If comments are closed. -->
            <p class="nocomments"><?php _e('Comments are closed.','multi-color'); ?></p>
    <?php endif; ?>
<?php endif; ?>

<?php if ( comments_open() ) : ?>
<div id="respond">
    <h3><?php _e('Leave a Comment','multi-color'); ?></h3>
    <div class="cancel-comment-reply">
        <small><?php cancel_comment_reply_link(); ?></small>
    </div>
    <?php if ( get_option('comment_registration') && !is_user_logged_in() ) : ?>
    <p><?php _e('You must be ','multi-color'); ?> <a href="<?php echo wp_login_url( get_permalink() ); ?>"><?php _e('logged in','multi-color'); ?></a> <?php _e('to post a comment.','multi-color'); ?></p>
    <?php else : ?>
    <form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">
    <table cellpadding="10">
    <?php if ( is_user_logged_in() ) : ?>
    <tr><td></td><td><?php _e('Logged in as','multi-color'); ?> <a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a>. <a href="<?php echo wp_logout_url(get_permalink()); ?>" title="<?php _e('Log out of this account','multi-color'); ?>"><?php _e('Log out','multi-color'); ?> &raquo;</a></td></tr>
    <?php else : ?>
    <tr><td><label for="author"><small><?php _e('Name','multi-color'); ?>: <?php if ($req) echo "*"; ?></small></label></td> <td><span class="textbox"><input type="text" name="author" id="author" value="<?php echo esc_attr($comment_author); ?>" tabindex="1" <?php if ($req) echo "aria-required='true'"; ?> /></span></td></tr>
    <tr><td><label for="email"><small><?php _e('Mail','multi-color'); ?>: <?php if ($req) echo "*"; ?></small></label></td> <td><span class="textbox"><input type="text" name="email" id="email" value="<?php echo esc_attr($comment_author_email); ?>" tabindex="2" <?php if ($req) echo "aria-required='true'"; ?> /></span></td></tr>
    <tr><td><label for="url"><small><?php _e('Website','multi-color'); ?>: </small></label></td> <td><span class="textbox"><input type="text" name="url" id="url" value="<?php echo esc_attr($comment_author_url); ?>" tabindex="3" /></span></td></tr>
    <?php endif; ?>
    <!--<p><small><strong>XHTML:</strong> You can use these tags: <code><?php echo allowed_tags(); ?></code></small></p>-->
    <tr><td><label for="comment"><small><?php _e('Message','multi-color'); ?>: </small></label></td> <td><span class="textarea"><textarea name="comment" id="comment" tabindex="4"></textarea></span></td></tr>
    <tr><td></td><td><?php _e('* are Required fields','multi-color'); ?><br /><br /><input name="submit" type="submit" id="submit" tabindex="5" value="<?php _e('Submit Comment','multi-color'); ?>" /><?php comment_id_fields(); ?></td></tr>
    </table>
    <?php do_action('comment_form', $post->ID); ?>
    </form>
    <?php endif; // If registration required and not logged in ?>
</div>
<br />
<br />
<?php endif; // if you delete this the sky will fall on your head ?>