    <div id="footer">
        <div class="footer_widget_area" id="footer_widget1">
            <ul>
                <?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar('Footer Widget 1') ) : else : ?>
                <?php endif; ?>
            </ul>
        </div>
        <div class="footer_widget_area" id="footer_widget2">
            <ul>
                <?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar('Footer Widget 2') ) : else : ?>
                <?php endif; ?>
            </ul>
        </div>
        <div class="footer_widget_area" id="footer_widget3">
            <ul>
                <?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar('Footer Widget 3') ) : else : ?>
                <?php endif; ?>
            </ul>
        </div>
        <div class="clear"></div>
        <div class="copyright">
            <p>&copy; <?php _e('Copyright','multi-color'); ?> <?php bloginfo('name'); ?></p>
        </div>
    </div>
</div><!-- End of Wrapper -->
<?php wp_footer(); ?>
</body>
</html>