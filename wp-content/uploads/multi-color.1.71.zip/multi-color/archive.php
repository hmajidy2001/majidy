<?php get_header(); ?>
<?php include(TEMPLATEPATH . '/init_options.php'); ?>
<?php if($options['mc_sidebar_layout'] == 'l') {
    include(TEMPLATEPATH . '/sidebar1.php');
} else if($options['mc_sidebar_layout'] == 'll') {
    include(TEMPLATEPATH . '/sidebar1.php');
    include(TEMPLATEPATH . '/sidebar2.php');
} else if($options['mc_sidebar_layout'] == 'lr') {
    include(TEMPLATEPATH . '/sidebar2.php');
}
?>
<div id="content">
    <?php $count = 0; ?>
    <?php if (have_posts()) : ?>
        <?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
        <?php /* If this is a category archive */ if (is_category()) { ?>
              <h2 class="pagetitle"><?php _e('Archive for the','multi-color'); ?> &#8216;<?php single_cat_title(); ?>&#8217; <?php _e('Category','multi-color'); ?></h2>
        <?php /* If this is a tag archive */ } elseif( is_tag() ) { ?>
              <h2 class="pagetitle"><?php _e('Posts Tagged','multi-color'); ?> &#8216;<?php single_tag_title(); ?>&#8217;</h2>
        <?php /* If this is a daily archive */ } elseif (is_day()) { ?>
              <h2 class="pagetitle"><?php _e('Archive for','multi-color'); ?> <?php the_time('F jS, Y'); ?></h2>
        <?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
              <h2 class="pagetitle"><?php _e('Archive for','multi-color'); ?> <?php the_time('F, Y'); ?></h2>
        <?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
              <h2 class="pagetitle"><?php _e('Archive for','multi-color'); ?> <?php the_time('Y'); ?></h2>
        <?php /* If this is an author archive */ } elseif (is_author()) { ?>
              <h2 class="pagetitle"><?php _e('Author Archive','multi-color'); ?></h2>
        <?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
              <h2 class="pagetitle"><?php _e('Blog Archives','multi-color'); ?></h2>
        <?php } ?>
        <?php while (have_posts()) : the_post(); $count ++; ?>
            <div <?php post_class('box-'.$count) ?> id="post-<?php the_ID(); ?>">
                <h2 class="posttitle"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php _e('Permanent Link to','multi-color'); ?> <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
                <div class="postinfo">
                    <span class="date"><?php the_time('M jS, y') ?></span>
                    / <span class="comments"><?php comments_popup_link('0 Comments', '1 Comment', '% Comments','','Comments Off'); ?></span>
                    <?php edit_post_link('Edit this Entry', '/<span class="edit-link">', '</span>'); ?>
                </div>
                <div class="entry">
                    <?php the_content('Read More'); ?>
                    <div class="clear"></div>
                    <?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
                </div>
                <?php if($options['mc_postmeta'] != 'none') { ?>
                    <?php if($options['mc_postmeta'] == 'categories') { ?>
                        <div class="postmeta"><span class="postcategory"><?php the_category(', ') ?></span></div>
                    <?php } else if($options['mc_postmeta'] == 'tags') { ?>
                        <div class="postmeta"><span class="posttags"><?php the_tags('<img src="'.get_bloginfo('template_url').'/images/tag_icon.png" />', ', ', ''); ?></span></div>
                    <?php } ?>
                <?php } ?>
            </div>
        <?php endwhile; ?>
        <?php include(TEMPLATEPATH . '/navigation.php'); ?>
    <?php else :
        if ( is_category() ) { ?>// If this is a category archive
            <h2 class='posttitle'><?php _e('Sorry, but there are no posts in the ','multi-color'); single_cat_title('',false); _e(' category yet.','multi-color');?></h2>
        <?php } else if ( is_date() ) { ?> // If this is a date archive
            <h2 class='posttitle'><?php _e('Sorry, but there are no posts with this date.','multi-color'); ?></h2>
        <?php } else if ( is_author() ) { // If this is a category archive
            $userdata = get_userdatabylogin(get_query_var('author_name')); ?>
            <h2 class='posttitle'><?php _e('Sorry, but there are no posts by ','multi-color'); echo $userdata->display_name; _e( 'yet.','multi-color'); ?></h2>
        <?php } else { ?>
            <h2 class='posttitle'><?php _e('No posts found.','multi-color'); ?></h2>
        <?php }
    endif; ?>
</div>
<?php if($options['mc_sidebar_layout'] == 'r') {
    include(TEMPLATEPATH . '/sidebar1.php');
} else if($options['mc_sidebar_layout'] == 'rr') {
    include(TEMPLATEPATH . '/sidebar1.php');
    include(TEMPLATEPATH . '/sidebar2.php');
} else if($options['mc_sidebar_layout'] == 'lr') {
    include(TEMPLATEPATH . '/sidebar1.php');
}
?>
<div class="clear"></div>
<?php get_footer(); ?>