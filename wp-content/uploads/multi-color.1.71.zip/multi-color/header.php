<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?></title>
<?php
    $options = get_option('mc_options');
    /* Default setting is One right sidebar layout */
    if(trim($options['mc_sidebar_layout']) == "") { $options['mc_sidebar_layout'] = 'r'; }
    if($options['mc_sidebar_layout'] == 'll' or $options['mc_sidebar_layout'] == 'rr' or $options['mc_sidebar_layout'] == 'lr') {
        /* Setting margins and dimensions for 2 sidebar layout */
        $contentmargin = "10px";
        $sidebarmargin = "10px";
        $contentwidth = "560px";
        $sidebarwidth = "240px";
        if($options['mc_sidebar_layout'] == 'll' or $options['mc_sidebar_layout'] == 'rr') {
            /* If 2 left or right sidebars then overriding content dimensions to add some extra space to the content */
            $contentmarginright = "margin-right: 20px;";
            $contentmarginleft = "margin-left: 20px;";
            $contentwidth = "530px";
        }
    } else if($options['mc_sidebar_layout'] == 'l' or $options['mc_sidebar_layout'] == 'r') {
        /* Setting margins and dimensions for 1 sidebar layout */
        $contentmargin = "30px";
        $sidebarmargin = "30px";
        $contentwidth = "680px";
        $sidebarwidth = "300px";
    } else {
        /* Setting margins and dimensions for NO sidebar layout */
        $contentmargin = "50px";
        $sidebarmargin = "50px";
        $contentwidth = "1000px";
    }
?>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<!-- Default Color Scheme Setting -->
<?php if(trim($options['mc_colorscheme']) == '') { $options['mc_colorscheme'] = 'brown'; } ?>
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style-<?php echo $options['mc_colorscheme']; ?>.css" type="text/css" media="screen" />
<!--[if IE]>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/style-ie.css" type="text/css" media="screen" />
<![endif]-->
<style type="text/css">
    #content { width: <?php echo $contentwidth; ?>; margin: 0 <?php echo $contentmargin; ?>; <?php echo $contentmarginright; ?> <?php echo $contentmarginleft; ?> }
    .sidebar { width: <?php echo $sidebarwidth; ?>; margin: 0 <?php echo $sidebarmargin; ?>; }
</style>
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<?php load_theme_textdomain('multi-color',get_bloginfo('template_url').'/languages');?>
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_enqueue_script("jquery"); ?>
<?php wp_head(); ?>
<script type="text/javascript" src="<?php echo get_bloginfo('template_url'); ?>/js/multi-color.js"></script>
</head>
<body>
<div id="wrapper">
    <div id="header">
        <h1><a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a></h1>
	<div class="description"><?php bloginfo('description'); ?></div>
    </div>
    <?php if(trim($options['mc_menu']) == "") { $options['mc_menu'] = 'pages'; } ?>
    <div class="menu">
        <ul>
            <?php if($options['mc_menu'] == 'pages') { ?><li id="home"<?php if(!is_page()) {?> class="current_page_item"<?php }?>><a href="<?php bloginfo('home'); ?>"><?php _e('Home','multi-color'); ?></a></li> <?php echo remove_title_attribute(wp_list_pages('depth=3&title_li=&echo=0')); ?><?php } ?>
            <?php if($options['mc_menu'] == 'categories') { ?><li id="home"<?php if(!is_page() && !is_category() ) {?> class="current-cat"<?php }?>><a href="<?php bloginfo('home'); ?>"><?php _e('Home','multi-color'); ?></a></li> <?php echo remove_title_attribute(wp_list_categories('depth=3&title_li=&number=10')); ?><?php } ?>
        </ul>
        <div class="clear"></div>
    </div>