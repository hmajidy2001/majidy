<?php
$defaultimg = "header";
define('HEADER_TEXTCOLOR', 'fff');
define('HEADER_IMAGE', '%s/images/'.$defaultimg.'.png'); // %s is theme dir uri
define('HEADER_IMAGE_WIDTH', 1100);
define('HEADER_IMAGE_HEIGHT', 200);
function mc_admin_header_style() {
?>
<style type="text/css">
  #headimg { background: url(<?php header_image() ?>) no-repeat; height: <?php echo HEADER_IMAGE_HEIGHT; ?>px; width: <?php echo HEADER_IMAGE_WIDTH; ?>px; }
  #headimg h1 { margin:0; padding: 52px 0 0 22px; font-size: 34px; font-weight: normal; text-shadow: #000 1px 1px 1px; font-family: Arial; }
  #headimg h1 a { text-decoration:none; border:0; }
  #headimg #desc { margin:0; padding:7px 0 0 22px; font-style:italic; text-shadow: #000 1px 1px 1px; }
  #headimg * { color:#<?php header_textcolor();?>; }
</style>
<?php }
function mc_header_style() {
?>
<style type="text/css">
  #header { background: url(<?php header_image() ?>) bottom no-repeat; height: <?php echo HEADER_IMAGE_HEIGHT; ?>px; width: <?php echo HEADER_IMAGE_WIDTH; ?>px; }  
  #header h1 { color:#<?php header_textcolor();?>; }
  #header h1 a { color:#<?php header_textcolor();?>; }
  #header .description { color:#<?php header_textcolor();?>; }
</style>
<?php
}
if ( function_exists('add_custom_image_header') ) {
    add_custom_image_header('mc_header_style', 'mc_admin_header_style');
} 
?>
<?php
function remove_title_attribute($subject) {
    $result = preg_replace('/title=\"(.*?)\"/','',$subject);
    return $result;
}
?>
<?php
    /** Theme Options **/
    /*******************/
    class mcOptions {
            function getOptions() {
                    $options = get_option('mc_options');
                    if (!is_array($options)) {
                        $options['mc_colorscheme'] = 'brown';
                        $options['mc_sidebar_layout'] = 'r';
                        $options['mc_menu'] = 'pages';
                        $options['mc_postmeta'] = 'categories';
                        $options['mc_postnav'] = true;
                        update_option('mc_options', $options);
                    }
                    return $options;
            }
            function add() {
                if(isset($_POST['mc_save'])) {
                    $options = mcOptions::getOptions();

                    if($_POST['mc_colorscheme'] == 'black') {
                        $options['mc_colorscheme'] = 'black';
                    }
                    else if($_POST['mc_colorscheme'] == 'gray') {
                        $options['mc_colorscheme'] = 'gray';
                    }
                    else {
                        $options['mc_colorscheme'] = 'brown';
                    }

                    if($_POST['mc_sidebar_layout'] == 'n') {
                        $options['mc_sidebar_layout'] = 'n';
                    }
                    else if($_POST['mc_sidebar_layout'] == 'l') {
                        $options['mc_sidebar_layout'] = 'l';
                    }
                    else if($_POST['mc_sidebar_layout'] == 'll') {
                        $options['mc_sidebar_layout'] = 'll';
                    }
                    else if($_POST['mc_sidebar_layout'] == 'rr') {
                        $options['mc_sidebar_layout'] = 'rr';
                    }
                    else if($_POST['mc_sidebar_layout'] == 'lr') {
                        $options['mc_sidebar_layout'] = 'lr';
                    }
                    else {
                        $options['mc_sidebar_layout'] = 'r';
                    }

                    if($_POST['mc_menu'] == 'categories') {
                        $options['mc_menu'] = 'categories';
                    }
                    else {
                        $options['mc_menu'] = 'pages';
                    }
                    
                    if($_POST['mc_postmeta'] == 'none') {
                        $options['mc_postmeta'] = 'none';
                    } else if($_POST['mc_postmeta'] == 'tags') {
                        $options['mc_postmeta'] = 'tags';
                    } else if($_POST['mc_postmeta'] == 'categories') {
                        $options['mc_postmeta'] = 'categories';
                    }
                    
                    if($_POST['mc_postnav']) {
			$options['mc_postnav'] = (bool)true;
		    } else {
			$options['mc_postnav'] = (bool)false;
		    }

                    update_option('mc_options', $options);
                } else if(isset($_POST['mc_delete'])) {
                    delete_option('mc_options');
                } else {
                    mcOptions::getOptions();
                }
                add_theme_page(__('Multi-Color Theme Options','multi-color'), __('Multi-Color Theme Options','multi-color'), 'edit_themes', basename(__FILE__), array('mcOptions', 'display'));
            }

            function display() {
                $options = mcOptions::getOptions();
    ?>
            <form action="#" method="post" enctype="multipart/form-data" name="mc_form" id="mc_form">
            <div class="wrap">
                <h2><?php _e('Multi-Color Theme Options','multi-color'); ?></h2>
                <?php if(isset($_POST['mc_save'])) { ?>
                    <div style="background: #FFF299; padding: 5px; border: 1px #FFDE99 solid;"><?php _e('Settings Saved','multi-color'); ?></div>
                <?php } else if(isset($_POST['mc_delete'])) { ?>
                    <div style="background: #FFF299; padding: 5px; border: 1px #FFDE99 solid;"><?php _e('Default Settings Restored','multi-color'); ?></div>
                <?php } ?>
                <hr>
                <p class="submit">
                    <input class="button-primary" type="submit" name="mc_save" value="<?php _e('Save Changes','multi-color'); ?>" />
                    <input class="button-primary" type="submit" style="margin-left: 20px;" name="mc_delete" value="<?php _e('Reset to Default Settings','multi-color'); ?>" />
                </p>
                <hr>
                <h3><?php _e('Color schemes','multi-color'); ?></h3>
                <table cellspacing="10">
                    <tr>
                        <td><?php _e('Choose your color scheme: ','multi-color'); ?></td>
                        <td><select name="mc_colorscheme">
                                <option value="brown" <?php if($options['mc_colorscheme'] == "brown") { ?> selected="selected" <?php } ?> ><?php _e('Brown & Blue','multi-color'); ?></option>
                                <option value="black"<?php if($options['mc_colorscheme'] == "black") { ?> selected="selected" <?php } ?> ><?php _e('Black & Red','multi-color'); ?></option>
                                <option value="gray"<?php if($options['mc_colorscheme'] == "gray") { ?> selected="selected" <?php } ?> ><?php _e('Gray & Pink','multi-color'); ?></option>
                            </select>
                        </td>
                    </tr>
                </table>
                <hr>
		<h3><?php _e('Sidebar Options','multi-color'); ?></h3>
		<table cellspacing="10">
                    <tr><td><?php _e('Choose your sidebar layout:','multi-color'); ?></td><td></td><td></td></tr>
                    <tr>
                        <td><input name="mc_sidebar_layout" type="radio" value="n" <?php if($options['mc_sidebar_layout'] == "n") echo 'checked'; ?> />&nbsp;&nbsp;<label><img src="<?php bloginfo('template_url');?>/images/optionpage/nosb.png" />&nbsp;&nbsp;<?php _e('No Sidebar','multi-color'); ?></label></td>
                        <td><input name="mc_sidebar_layout" type="radio" value="l" <?php if($options['mc_sidebar_layout'] == "l") echo 'checked'; ?> />&nbsp;&nbsp;<label><img src="<?php bloginfo('template_url');?>/images/optionpage/lsb.png" />&nbsp;&nbsp;<?php _e('One Left Sidebar','multi-color'); ?></label></td>
                    </tr>
                    <tr>
                        <td><input name="mc_sidebar_layout" type="radio" value="r" <?php if($options['mc_sidebar_layout'] == "r") echo 'checked'; ?> />&nbsp;&nbsp;<label><img src="<?php bloginfo('template_url');?>/images/optionpage/rsb.png" />&nbsp;&nbsp;<?php _e('One Right Sidebar','multi-color'); ?></label></td>
                        <td><input name="mc_sidebar_layout" type="radio" value="ll" <?php if($options['mc_sidebar_layout'] == "ll") echo 'checked'; ?> />&nbsp;&nbsp;<label><img src="<?php bloginfo('template_url');?>/images/optionpage/2lsb.png" />&nbsp;&nbsp;<?php _e('Two Left Sidebars','multi-color'); ?></label></td>
                    </tr>
                    <tr>
                        <td><input name="mc_sidebar_layout" type="radio" value="rr" <?php if($options['mc_sidebar_layout'] == "rr") echo 'checked'; ?> />&nbsp;&nbsp;<label><img src="<?php bloginfo('template_url');?>/images/optionpage/2rsb.png" />&nbsp;&nbsp;<?php _e('Two Right Sidebars','multi-color'); ?></label></td>
                        <td><input name="mc_sidebar_layout" type="radio" value="lr" <?php if($options['mc_sidebar_layout'] == "lr") echo 'checked'; ?> />&nbsp;&nbsp;<label><img src="<?php bloginfo('template_url');?>/images/optionpage/lrsb.png" />&nbsp;&nbsp;<?php _e('Two Sidebars with Content in center','multi-color'); ?></label></td>
                    </tr>
                </table>
                <hr>
                <h3><?php _e('Page Menu or Category Menu','multi-color'); ?></h3>
                <table cellspacing="10">
                    <tr>
                        <td><?php _e('Display pages or categories as dropdown menu: ','multi-color'); ?></td>
                        <td><select name="mc_menu">
                                <option value="pages" <?php if($options['mc_menu'] == "pages") { ?> selected="selected" <?php } ?> ><?php _e('Pages','multi-color'); ?></option>
                                <option value="categories"<?php if($options['mc_menu'] == "categories") { ?> selected="selected" <?php } ?> ><?php _e('Categories','multi-color'); ?></option>
                            </select>
                        </td>
                    </tr>
                </table>
                <hr>
                <h3><?php _e('Post Meta Options','multi-color'); ?></h3>
                <table cellspacing="10">
                    <tr>
                        <td><?php _e('Display Categories or Tags or Nothing under each post : ','multi-color'); ?></td>
                        <td><select name="mc_postmeta">
                                <option value="none" <?php if($options['mc_postmeta'] == "none") { ?> selected="selected" <?php } ?> ><?php _e('None','multi-color'); ?></option>
                                <option value="tags" <?php if($options['mc_postmeta'] == "tags") { ?> selected="selected" <?php } ?> ><?php _e('Tags','multi-color'); ?></option>
                                <option value="categories"<?php if($options['mc_postmeta'] == "categories") { ?> selected="selected" <?php } ?> ><?php _e('Categories','multi-color'); ?></option>
                            </select>
                        </td>
                    </tr>
                </table>
                <hr>
                <h3><?php _e('Single Post Entry Navigation Option','multi-color'); ?></h3>
                <table cellspacing="10">
                    <tr>
                        <td><?php _e('Display navigation on Single post page ?: ','multi-color'); ?></td>
                        <td><input name="mc_postnav" type="checkbox" value="checkbox" <?php if($options['mc_postnav']) echo "checked='checked'"; ?> /></td>
                    </tr>
                </table>
                <hr>
                <p class="submit">
                    <input class="button-primary" type="submit" name="mc_save" value="<?php _e('Save Changes','multi-color'); ?>" />
                    <input class="button-primary" type="submit" style="margin-left: 20px;" name="mc_delete" value="<?php _e('Reset to Default Settings','multi-color'); ?>" />
                </p>
            </div>
    <?php
            }
    }

    add_action('admin_menu', array('mcOptions', 'add'));

    /** Sidebar Function **/
    /**********************/
    $options = get_option('mc_options');
    if($options['mc_sidebar_layout'] == "l" or $options['mc_sidebar_layout'] == "r") {
	$number_sidebars = 1;
    }
    else if($options['mc_sidebar_layout'] == 'll' or $options['mc_sidebar_layout'] == 'rr' or $options['mc_sidebar_layout'] == 'lr') {
	$number_sidebars = 2;
    }
    else if($options['mc_sidebar_layout'] == 'n') {
	$number_sidebars = 0;
    }
    
    if ( function_exists('register_sidebars') ) {
        register_sidebars($number_sidebars,array('before_widget' => '<li>','after_widget' => '</li>','before_title' => '<h2>','after_title' => '</h2>'));
        register_sidebar(array('name' => 'Footer Widget 1','before_widget' => '<li>','after_widget' => '</li>','before_title' => '<h2>','after_title' => '</h2>'));
        register_sidebar(array('name' => 'Footer Widget 2','before_widget' => '<li>','after_widget' => '</li>','before_title' => '<h2>','after_title' => '</h2>'));
        register_sidebar(array('name' => 'Footer Widget 3','before_widget' => '<li>','after_widget' => '</li>','before_title' => '<h2>','after_title' => '</h2>'));
    }
?>
<?php
function comments_callback($comment, $args, $depth) { $GLOBALS['comment'] = $comment; ?>
  <li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">
    <div style="padding-right: 15px;" id="comment-<?php comment_ID(); ?>">
      <div class="comment-author vcard">
        <p class="gravatar"><?php if(function_exists('get_avatar')) { echo get_avatar($comment, '48', get_bloginfo('template_url').'/images/avatar.png'); } ?></p>
      </div>
      <div class="comment-meta">
        <p class="authorname"><?php comment_author_link() ?></p>
        <p class="commentdate"><?php printf( __('%1$s'), get_comment_time(__('F jS, Y')) ); ?></p>
        <p class="comment-reply"><?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?></p>
        <p><?php edit_comment_link(__('Edit this Comment','multi-color'),'',''); ?></p>
      </div>
      <div class="return-link"><a href="javascript: void(0)" onclick="smoothscroll('wrapper')" title="<?php _e('Return to top','multi-color'); ?>"><img src="<?php bloginfo('template_url'); ?>/images/return_icon.png" /></a></div>
      <div class="clear"></div>
      <div class="comment-text">
        <?php if ($comment->comment_approved == '0') : ?>
          <p><?php _e('Your comment is awaiting moderation.','multi-color') ?></p>
        <?php endif; ?>
        <?php comment_text() ?>
      </div>      
    </div>
<?php } ?>
<?php
function trackbacks_callback($comment, $args, $depth) { $GLOBALS['comment'] = $comment; ?>
  <li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">
    <div style="padding-right: 15px;" id="comment-<?php comment_ID(); ?>">
      <div class="comment-meta">
        <p class="authorname"><?php comment_author_link() ?></p>
        <p class="commentdate"><?php printf( __('%1$s'), get_comment_time(__('F jS, Y')) ); ?></p>
        <p class="comment-reply"><?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?></p>
        <p><?php edit_comment_link(__('Edit this Comment','multi-color'),'',''); ?></p>
      </div>
      <div class="return-link"><a href="javascript: void(0)" onclick="smoothscroll('wrapper')" title="<?php _e('Return to top','multi-color'); ?>"><img src="<?php bloginfo('template_url'); ?>/images/return_icon.png" /></a></div>
      <div class="clear"></div>
      <div class="comment-text">
        <?php if ($comment->comment_approved == '0') : ?>
          <p><?php _e('Your comment is awaiting moderation.','multi-color') ?></p>
        <?php endif; ?>
        <?php comment_text() ?>
      </div>
    </div>
<?php } ?>